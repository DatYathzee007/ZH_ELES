﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laszlo_Juhasz_IL41ML.Attributes
{
    [AttributeUsage(AttributeTargets.Property)]
    class StringRangeAttribute : Attribute
    {
        public List<string> Range { get; set; }
        
    }
}
