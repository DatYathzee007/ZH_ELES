﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laszlo_Juhasz_IL41ML.Entities
{
    [Table("Actors")]
    public class Actor
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        [MaxLength(50)]
        public string Name { get; set; }
        public string Sex { get; set; }

        [ForeignKey(nameof(Movie))]
        public int MovieId { get; set; }
        [NotMapped]
        public virtual Movie Movie { get; set; }

        public override string ToString()
        {
            return $"";
        }
    }
}
