﻿using Laszlo_Juhasz_IL41ML.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laszlo_Juhasz_IL41ML.Entities
{
    [Table("Movies")]
    public class Movie
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string Title { get; set; }
        [StringRange]
        public string Genre { get; set; }
        [StringRange]
        public string Rating { get; set; }
        public int YearOfRelease { get; set; }

        [NotMapped]
        public virtual ICollection<Actor> Actors { get; set; }

        public override string ToString()
        {
            return $"{this.Id} - {this.Title} - {this.Genre} - {this.Rating} - {this.YearOfRelease}";
        }
    }
}
