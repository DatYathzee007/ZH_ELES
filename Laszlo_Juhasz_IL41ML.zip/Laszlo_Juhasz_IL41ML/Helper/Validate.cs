﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laszlo_Juhasz_IL41ML.Helper
{
    class Validate
    {
        public static bool IsValid<T>(string propertyName)
        {
            bool result = false;


            return result;
        }
    }
}
