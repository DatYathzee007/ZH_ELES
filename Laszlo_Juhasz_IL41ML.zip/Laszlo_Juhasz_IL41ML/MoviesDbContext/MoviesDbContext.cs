﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laszlo_Juhasz_IL41ML.Entities;
using Microsoft.EntityFrameworkCore;

namespace Laszlo_Juhasz_IL41ML
{
    class MoviesDbContext : DbContext
    {
        public DbSet<Actor> Actors { get; set; }
        public DbSet<Movie> Movies { get; set; }
        public MoviesDbContext()
        {
            Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder
                    .UseLazyLoadingProxies()
                    .UseSqlServer(@"Server = (LocalDB)\MSSQLLocalDB; AttachDbFilename =|DataDirectory|\Movies.mdf; Trusted_Connection =True;");
                    
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Actor>(
                x=>x
                .HasOne(movie => movie.Movie)
                .WithMany(actor => actor.Actors)
                .HasForeignKey(key => key.MovieId)
                .OnDelete(DeleteBehavior.NoAction));

            
            //modelBuilder.Entity<Actor>().HasData();
            //modelBuilder.Entity<Movie>().HasData();
        }
    }
}
