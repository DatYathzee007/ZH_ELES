﻿using System;
using System.Linq;
using Laszlo_Juhasz_IL41ML.Entities;
using Laszlo_Juhasz_IL41ML.xmlloading;


namespace Laszlo_Juhasz_IL41ML
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program Started...");
            var xml = new LoadingXml("Movies.xml");
            Console.WriteLine("xml loaded!");
            var db = new MoviesDbContext();
            Console.WriteLine("DB loaded!");
            /*Solve these exercises using linq queries.
a)	Display the number of actors in the database on the console. (1 point)
b)	Display the male actors on the console. (1 point)
c)	Display the most recent movie(1 point)
d)	Display the oldest movie that has a femail actor in it(2.5 points)
e)	Display the movies that contain female actors in ascending order of their year of creation. (2.5 points)
            f)	For each movie, display a data structure, which contains the name of the movie and the female and male actors separately in ascending order of the actor’s name. (3 points)
g)	For each movie genre, find the the movie that has the most male actors, then project it into a data structure that contains the Genre, the Name of the movie and the NumberOfMaleActors property. (3 points)
*/

            var resulta = db.Actors.Count();
            var resultb = db.Actors.Where(x => x.Sex == "Male");
            //var resultc = db.Movies






        }
    }
}
