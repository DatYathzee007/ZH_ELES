﻿using Laszlo_Juhasz_IL41ML.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Laszlo_Juhasz_IL41ML.xmlloading
{
    class LoadingXml
    {
        public string xml { get; set; }
        public LoadingXml(string xml)
        {
            this.xml = xml;
        }
        public static List<Movie> XMLLOADER(string xml) {
            
            var doc = XDocument.Load(xml);
            var movies = doc.Root.Descendants("Movie");
            var loadedMovies = new List<Movie>();
            foreach (var movie in movies)
            {
                List<Actor> actorlist = new();
                IEnumerable<XElement> actors = movie.Descendants("Actors");
                foreach (XElement actor in actors)
                {
                    actorlist.Add(new Actor()
                    {
                        Name = actor.Element("Name").Value,
                        Sex = actor.Element("Sex").Value
                    });
                }

                loadedMovies.Add(new Movie() {
                    Title = movie.Element("Title").Value,
                    Genre = movie.Element("Genre").Value,
                    Rating = movie.Element("Rating").Value,
                    YearOfRelease = int.Parse(movie.Element("YearOfRelease").Value),
                    Actors = actorlist
                }) ;
            }
            
        return loadedMovies;
        }
    }
}
